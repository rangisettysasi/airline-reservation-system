from django.contrib.auth import update_session_auth_hash
from django.contrib.auth.forms import PasswordChangeForm
from django.core.checks import messages
from django.db.models import Q
from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.shortcuts import render
import qrcode
from .forms import MyForm

from io import BytesIO

from .models import Admin, flight, user, customerCareEmp, BookingHistory


# from .models import Admin


def adminhome(request):
    return render(request, "adminhome.html")


def logout(request):
    return render(request, "login.html")


def checkadminlogin(request):
    adminuname = request.POST["uname"]
    adminpwd = request.POST["pwd"]
    flag = Admin.objects.filter(Q(username=adminuname) & Q(password=adminpwd))
    print(flag)

    if flag:
        return render(request, "adminhome.html")

    else:
        return HttpResponse("Login Failed !!")


def viewusers(request):
    admin=Admin.objects.all()
    count=Admin.objects.all()
    return render(request, "viewusers.html",{"AdminData":admin,"count":count})



def viewflight(request):
    flight1=flight.objects.all()
    count=flight.objects.all()
    return render(request, "viewflights.html",{"FlightsData":flight1,"count":count})




def viewemployee(request):
    emp=customerCareEmp.objects.all()
    count=customerCareEmp.objects.all()
    return render(request, "viewemployees.html",{"EmpData":emp,"count":count})


def viewusers(request):
    user1=user.objects.all()
    count=user.objects.all()
    return render(request, "viewusers.html",{"UserData":user1,"count":count})



def generate_qr_code(request):
    if request.method == 'POST':
        money = request.POST.get('money')
        # Generate a QR code with the money value
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(money)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        response = HttpResponse(content_type="image/png")
        img.save(response, "PNG")
        return response
    return render(request, 'qrcode.html')

def changepassword(request):
    if request.method == 'POST':
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)  # Important for maintaining the session

            messages.success(request, 'Your password was successfully changed.')
            return redirect('changepassword')  # You can redirect to a success page or another page

        else:
            messages.error(request, 'Please correct the error(s) below.')

    else:
        form = PasswordChangeForm(request.user)

    return render(request, 'changepassword.html', {'form': form})

def booking(request):
    if request.method == 'POST':
        departure = request.POST['departure']
        destination = request.POST['destination']
        date = request.POST['date']

        # In a real-world application, you would perform a database query
        # or connect to an API to fetch flight data based on the user's search criteria.
        # For this example, we'll simulate some flight data.

        flight_data = [
            {
                'flight_number': 'Flight 1',
                'departure_time': '9:00 AM',
                'arrival_time': '11:00 AM',
                'price': '$250',
            },
            {
                'flight_number': 'Flight 2',
                'departure_time': '12:00 PM',
                'arrival_time': '2:00 PM',
                'price': '$280',
            },
        ]

        return render(request, 'booking.html', {
            'departure': departure,
            'destination': destination,
            'date': date,
            'flight_data': flight_data,
        })

    return render(request, 'booking.html')


def flight_search(request):
    if request.method == 'POST':
        form = MyForm(request.POST)
        if form.is_valid():
            departure_date = form.cleaned_data['departure_date']
            departure_time = form.cleaned_data['departure_time']
            flights = MyForm.objects.filter(departure_date=departure_date, departure_time=departure_time)
        else:
            flights = None
    else:
        form = MyForm()
        flights = None

    return render(request, 'SearchFlights.html', {'form': form, 'flights': flights})


def booking_history(request):
    history_entries = BookingHistory.objects.all()
    return render(request, 'history.html', {'history_entries': history_entries})