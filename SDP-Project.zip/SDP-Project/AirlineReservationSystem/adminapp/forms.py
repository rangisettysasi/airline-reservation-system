from django import forms

class MyForm(forms.Form):
    field1 = forms.CharField(max_length=100, label="Field 1")
    field2 = forms.IntegerField()
    departure_date = forms.DateField()  # Or forms.DateTimeField() for date and time
    departure_time = forms.TimeField()