from django.contrib import admin
from .models import Admin,flight,user,customerCareEmp
# Register your models here.
admin.site.register(user)
admin.site.register(flight)
admin.site.register(Admin)
admin.site.register(customerCareEmp)