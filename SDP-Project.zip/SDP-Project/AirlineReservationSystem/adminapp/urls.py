
from django.urls import path
from . import views

urlpatterns = [
    path("adminhome",views.adminhome,name="adminhome"),
    path("logout",views.logout,name="adminlogout"),
    path("checkloginadmin", views.checkadminlogin, name="checkloginadmin"),
    path("viewusers", views.viewusers, name="viewusers"),
    path("viewflights", views.viewflight, name="viewflights"),
    path('changepassword', views.changepassword, name='changepassword'),
    path('search', views.booking, name='search'),
    path('searchFlights', views.flight_search, name='searchFlights'),

    path("viewemployees", views.checkadminlogin, name="viewemployees"),
    path("booking", views.generate_qr_code, name='booking'),
    path('history', views.booking_history, name='history'),




]
