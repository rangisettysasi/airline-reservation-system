import datetime

import pycountry
from django.db import models
class Admin(models.Model):
    id = models.AutoField(primary_key=True)
    username = models.CharField(max_length=100, blank=False, unique=True)
    password = models.CharField(max_length=100, blank=False)

    class Meta:
        db_table = "admin_table"

    def __str__(self):
        return self.username


class flight(models.Model):
    flightCode = models.CharField(max_length=100, blank=False,primary_key=True)
    flightCompany = models.CharField(max_length=100, blank=False, unique=True)
    class Meta:
        db_table = "flight_table"

    def __str__(self):
        return self.flightCode

class Flight1(models.Model):
    flightCode = models.CharField(max_length=100, blank=False, primary_key=True)
    flightCompany = models.CharField(max_length=100, blank=False, unique=True)

    class Meta:
        db_table = "flight1_table"

    def __str__(self):
        return self.flightCode


class user(models.Model):
    userid = models.BigIntegerField(blank=False, unique=True)
    fullname = models.CharField(max_length=100, blank=False)
    gender_choices = (("MALE", "MALE"), ("FEMALE", "FEMALE"), ("OTHERS", "OTHERS"))
    gender = models.CharField(max_length=20, blank=False, choices=gender_choices)
    country_choices = [(country.alpha_2, country.name) for country in pycountry.countries]
    COUNTRY_CHOICES = tuple(country_choices)
    country = models.CharField(max_length=100, blank=False,choices=COUNTRY_CHOICES)
    current_year = datetime.date.today().year

    # Define the range of years, months, and dates
    start_year = 1990
    end_year = 2023

    # Generate a list of years in the range
    year_choices = [(year, str(year)) for year in range(start_year, end_year + 1)]
    YEAR_CHOICES = tuple(year_choices)
    year = models.IntegerField(blank=False,choices=YEAR_CHOICES)
    month_choices = [(month, datetime.date(1900, month, 1).strftime('%B')) for month in range(1, 13)]
    MONTH_CHOICES = tuple(month_choices)
    month = models.IntegerField(blank=False,choices=MONTH_CHOICES)
    date_choices = [(day, str(day)) for day in range(1, 32)]
    DATE_CHOICES = tuple(date_choices)
    date = models.IntegerField(blank=False,choices=DATE_CHOICES)
    password = models.CharField(max_length=100, blank=False, default="Nextgen")
    email = models.CharField(max_length=100, blank=False, unique=True)
    contact = models.CharField(max_length=20, blank=False, unique=True)

    class Meta:
        db_table = "user_table"

    def __str__(self):
        return self.fullname

class customerCareEmp(models.Model):
    id = models.AutoField(primary_key=True)
    empid = models.BigIntegerField(blank=False, unique=True)
    fullname = models.CharField(max_length=100, blank=False)
    gender_choices = (("MALE", "MALE"), ("FEMALE", "FEMALE"), ("OTHERS", "OTHERS"))
    gender = models.CharField(max_length=20, blank=False,choices=gender_choices)
    qualification = models.CharField(max_length=100, blank=False)
    designation = models.CharField(max_length=100, blank=False)
    country_choices = [(country.alpha_2, country.name) for country in pycountry.countries]
    COUNTRY_CHOICES = tuple(country_choices)
    country = models.CharField(max_length=100, blank=False, choices=COUNTRY_CHOICES)
    password = models.CharField(max_length=100, blank=False, default="Nextgen")
    email = models.CharField(max_length=100, blank=False, unique=True)
    contact = models.CharField(max_length=20, blank=False, unique=True)

    class Meta:
        db_table = "customerCare_table"

    def __str__(self):
        return self.fullname


class BookingHistory(models.Model):
    location = models.CharField(max_length=100)
    destination = models.CharField(max_length=100)
    flight = models.CharField(max_length=100)
    upi_id = models.CharField(max_length=100)

    def __str__(self):
        return f'{self.location} to {self.destination}'
