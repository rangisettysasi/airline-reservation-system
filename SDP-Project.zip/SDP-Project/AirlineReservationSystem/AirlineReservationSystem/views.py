from django.db.models import Q
from django.http import HttpResponse
from django.shortcuts import render



def demofunction(request):
    return HttpResponse("AIRLINE RESERVATION SYSTEM")

def demofunction1(request):
    return HttpResponse("<font color='black'>AIRLINE RESERVATION SYSTEM</font>")

def homefunction(request):
    return render(request,"index.html")

def aboutfunction(request):
    return render(request,"about.html")

def loginfunction(request):
    return render(request,"login.html")

def contactUsfunction(request):
    return render(request,"contact.html")

